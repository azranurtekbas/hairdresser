﻿namespace haircaredeneme.Models
{
    public class Admin
    {
        public int Id { get; set; }
        public string AdminMail { get; set; }
    }
}
