﻿// Çalışanlar tablosunu getir
function fetchCalisanlar() {
    fetch('http://localhost:5000/api/calisanlar')
        .then(response => response.json())
        .then(data => {
            const tableBody = document.querySelector('#calisanlar-table tbody');
            tableBody.innerHTML = '';

            data.forEach(calisan => {
                const row = `
                    <tr>
                        <td>${calisan.id}</td>
                        <td><input type="text" value="${calisan.ad}" onchange="updateCalisan(${calisan.id}, this.value, 'ad')"></td>
                        <td><input type="text" value="${calisan.uzmanlik}" onchange="updateCalisan(${calisan.id}, this.value, 'uzmanlik')"></td>
                        <td><input type="text" value="${calisan.telefon}" onchange="updateCalisan(${calisan.id}, this.value, 'telefon')"></td>
                        <td><button onclick="deleteCalisan(${calisan.id})">Sil</button></td>
                    </tr>
                `;
                tableBody.innerHTML += row;
            });
        });
}

// Yeni çalışan ekle
function addNewCalisan() {
    const newCalisan = {
        ad: 'Yeni Çalışan',
        uzmanlik: '',
        telefon: ''
    };

    fetch('http://localhost:5000/api/calisanlar', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newCalisan)
    }).then(() => fetchCalisanlar());
}

// Çalışan güncelle
function updateCalisan(id, value, field) {
    const updateData = { [field]: value };

    fetch(`http://localhost:5000/api/calisanlar/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updateData)
    }).then(() => fetchCalisanlar());
}

// Çalışan sil
function deleteCalisan(id) {
    fetch(`http://localhost:5000/api/calisanlar/${id}`, { method: 'DELETE' })
        .then(() => fetchCalisanlar());
}

// Benzer fonksiyonlar işlemler ve randevular için de yapılabilir

// Sayfa yüklendiğinde tüm tabloları getir
document.addEventListener('DOMContentLoaded', () => {
    fetchCalisanlar();
    fetchIslemler();
    fetchRandevular();
});
