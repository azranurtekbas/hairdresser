﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace haircaredeneme.Migrations
{
    /// <inheritdoc />
    public partial class create2 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            // Veritabanı kolonu için dönüşüm
            migrationBuilder.Sql("ALTER TABLE \"Calisanlar\" ALTER COLUMN \"UygunlukSaati\" TYPE interval USING \"UygunlukSaati\"::interval;");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            // Geri alma işlemi
            migrationBuilder.Sql("ALTER TABLE \"Calisanlar\" ALTER COLUMN \"UygunlukSaati\" TYPE text USING \"UygunlukSaati\"::text;");
        }
    }
}
