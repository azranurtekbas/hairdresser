﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace haircaredeneme.Migrations
{
    /// <inheritdoc />
    public partial class c5 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Islemler_Calisanlar_Id",
                table: "Islemler");

            migrationBuilder.RenameColumn(
                name: "Id",
                table: "Islemler",
                newName: "CalısanId");

            migrationBuilder.RenameIndex(
                name: "IX_Islemler_Id",
                table: "Islemler",
                newName: "IX_Islemler_CalısanId");

            migrationBuilder.AddForeignKey(
                name: "FK_Islemler_Calisanlar_CalısanId",
                table: "Islemler",
                column: "CalısanId",
                principalTable: "Calisanlar",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Islemler_Calisanlar_CalısanId",
                table: "Islemler");

            migrationBuilder.RenameColumn(
                name: "CalısanId",
                table: "Islemler",
                newName: "Id");

            migrationBuilder.RenameIndex(
                name: "IX_Islemler_CalısanId",
                table: "Islemler",
                newName: "IX_Islemler_Id");

            migrationBuilder.AddForeignKey(
                name: "FK_Islemler_Calisanlar_Id",
                table: "Islemler",
                column: "Id",
                principalTable: "Calisanlar",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
